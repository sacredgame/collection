package com.cg.bpw.ui;

import java.util.Scanner;

import com.cg.bpw.dto.User;
import com.cg.bpw.exception.PaymentWalletException;
import com.cg.bpw.service.BankServiceImpl;

public class Main 
{
	public static void main(String args[]) throws PaymentWalletException
	{
		BankServiceImpl service = new BankServiceImpl();
		Scanner sc = new Scanner(System.in);
		String name,mobileNo;
		float age;
		double amount;
		int ch = 0;
		do{
			System.out.println("1.Add User\n2.Deposit Money\n3.Withdraw Money\n4.Fund transfer\n5.Check Wallet balance\n6.Close Application");
			System.out.println("Enter your choice : ");
			ch = sc.nextInt();
			User user;
			switch(ch){
				case 1 :					
						do{
							do{
							System.out.println("Enter User Name : ");
							name = sc.next();
							if(service.validateName(name))
								break;
							}while(true);
							
							do{
							System.out.println("Enter User Mobile No. : ");
							mobileNo = sc.next();
							if(service.validateMoileNo(mobileNo))
								break;
							}while(true);
							
							do{
							System.out.println("Enter User Age : ");
							age = sc.nextFloat();
							if(service.validateAge(age))
								break;
							}while(true);
							
							do{
							System.out.println("Enter Initial Wallet Amount : ");
							amount = sc.nextDouble();
							if(service.validateAmount(amount))
								break;
							}while(true);
							
							if(service.validateAccount(mobileNo))
								System.out.println("User already exists!");
							else
								break;
							
						}while(true);
						
						user = new User();
						user.setName(name);
						user.setMobileNo(mobileNo);
						user.setAge(age);
						user.setInitialBalance(amount);
						service.createAccount(user);		
						System.out.println("User added\n"+" Name: "+user.getName()+" Mobile"
								+ "No: "+user.getMobileNo()+" Age: "+user.getAge()+" Initial Wallet blance: "+user.getInitialBalance());
					break;
					
				case 2 :
						
							do{
								System.out.println("Enter your Mobile No. : ");
								mobileNo = sc.next();
								if(service.validateMoileNo(mobileNo)) {
								if(!service.validateAccount(mobileNo))
									System.out.println("User Account not found! Check mobile number");
								else
									break;
							}}while(true);
							
							do{
								System.out.println("Enter amount you want to add to your wallet: ");
								amount = sc.nextDouble();
								if(service.validateAmount(amount))
									break;
								}while(true);
							
						service.addMoney(mobileNo, amount);		
					
					break;
					
				case 3 :
						do{
							System.out.println("Enter your mobile no. : ");
							mobileNo = sc.next();
							if(service.validateMoileNo(mobileNo))
							{
								if(!service.validateAccount(mobileNo))
									System.out.println("User account not found! please Check your mobile number");
								else
									break;
							}
						}while(true);
						
						do{
							System.out.println("Enter amount you want to send to your Bank account: ");
							amount = sc.nextDouble();
							if(service.validateAmount(amount))
								break;
							}while(true);					
					
					service.withdraw(mobileNo, amount);
					break;
				
				case 4 :
						String mobileNoReciever;
						do{
							do{
							System.out.println("Enter your mobile number : ");
							mobileNo = sc.next();
							if(service.validateMoileNo(mobileNo)){
								if(service.validateAccount(mobileNo))
									break;
								else
									System.out.println("User Account doesnt exists!");
							}
							}while(true);
							
							do{
							System.out.println("Enter the amount you want to send : ");
							amount = sc.nextDouble();
							if(service.validateAmount(amount))
								break;
							}while(true);
							
							do{
							System.out.println("Enter receivers mobile number : ");
							mobileNoReciever = sc.next();
							if(service.validateMoileNo(mobileNoReciever)){
								if(service.validateAccount(mobileNoReciever))
									break;
								else
									System.out.println("User Account doesnt exists!");
							}
							}while(true);
							
							if(!mobileNo.equals(mobileNoReciever))
								break;
							else
								System.out.println("Sender and receiver mobile number cannot be same.");
							}while(true);							
						service.moneyTransfer(mobileNo, mobileNoReciever, amount);
						break;
					
				case 5 :
						do{
							System.out.println("Enter the mobile number to check balance");
							mobileNo = sc.next();
							if(service.validateMoileNo(mobileNo)){
								if(service.validateAccount(mobileNo))
									break;
								else
									System.out.println("User Account doesnt exists!");
							}
						}while(true);
						
						System.out.println("Current Balance "+service.checkBalance(mobileNo));
						
					break;
					
				case 6 :
						System.out.println("Application terminated");
					break;
				default : System.out.println("Invalid entry!");
			}
			
		}while(ch != 6);
		sc.close();
		
	}
}
