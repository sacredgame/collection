package com.cg.bpw.exception;

public class PaymentWalletException extends Exception{
	public PaymentWalletException(String message){
		super(message);
	}
}
