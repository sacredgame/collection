package com.cg.bpw.dao;
import java.util.HashMap;
import java.util.Map;
import com.cg.bpw.dto.User;
import com.cg.bpw.exception.PaymentWalletException;

public class BankDAOImpl implements IBankDAO{
	
	Map<String,User> userMap;
	
	public BankDAOImpl(){
		userMap = new HashMap<>();
		userMap.put("8907652341", new User("8907652341", "Raj", 20, 5000));
		userMap.put("9078653421", new User("9078653421", "Mahesh", 25, 6000));
		userMap.put("7843290812", new User("7843290812", "Vinay", 43, 10000));
		userMap.put("6698120341", new User("6698120341", "Jigar", 73, 2000));
	}

	@Override
	public void createAccount(User customer) //Adding Customer Account
	{
		userMap.put(customer.getMobileNo(),customer);
	}

	@Override
	public void addMoney(String mobileNo, double amount) //Depositing Amount
	{
		User customer = userMap.get(mobileNo);
		if(customer != null){
			double updateAmount = customer.getInitialBalance();
			updateAmount += amount;
			customer.setInitialBalance(updateAmount);
			userMap.put(mobileNo, customer);
			System.out.println("Money Added to the Wallet! Wallet Balance: "+ customer.getInitialBalance());
		}
	}

	
	@Override
	public void withdraw(String mobileNo, double withdrawAmount) //Withdrawing Amount
	{
		User customer = userMap.get(mobileNo);
		if(customer != null){
			double amount = customer.getInitialBalance();	
			if(amount - withdrawAmount > 100){
				amount -= withdrawAmount;
				customer.setInitialBalance(amount);
				userMap.put(mobileNo, customer);
				System.out.println("Money Transfered! Wallet Balance: "+ customer.getInitialBalance());
			}
			else{
				System.out.println("Cannot transfer! Minimum balance of 100 should be maintained");
			}
			}
		
	}

	@Override
	public double checkBalance(String mobileNo) //Checking Account Balance
	{
		User custCheckBalance = userMap.get(mobileNo);
		double amount = custCheckBalance.getInitialBalance();
		return amount;
		
	}

	@Override
	public void moneyTransfer(String sender, String reciever, double amount) //Money Transfer from one account to other
	{		
		User custSender =  userMap.get(sender);
		User custReciever = userMap.get(reciever);
		double recieverAmount = custReciever.getInitialBalance();
		double senderAmount = custSender.getInitialBalance();
		if(senderAmount - amount > 100){
			recieverAmount += amount;
			senderAmount -= amount;
			custSender.setInitialBalance(senderAmount);
			userMap.put(custSender.getMobileNo(), custSender);
			custReciever.setInitialBalance(recieverAmount);
			userMap.put(custReciever.getMobileNo(), custReciever);	
			System.out.println("Money Transferred! Wallet Balance :"+senderAmount);
		}
		else{
			System.out.println("Cannot transfer! Minimum balance of 100 should be maintained in Sender's account");
		}
		
	}

	@Override
	public boolean validateAccount(String mobileNo) throws PaymentWalletException {
		User customer = userMap.get(mobileNo);
		if(customer == null)
			return false;
		return true;
	}

}
