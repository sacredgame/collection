package com.cg.bpw.dao;

import com.cg.bpw.dto.User;
import com.cg.bpw.exception.PaymentWalletException;

public interface IBankDAO {

	public void createAccount(User customer);
	
	public void addMoney(String mobileNo, double amount);
	
	public void withdraw(String mobileNo, double amount);
	
	public double checkBalance(String mobileNo);
	
	public void moneyTransfer(String sender, String reciever, double amount);
	
	public boolean validateAccount(String mobileNo) throws PaymentWalletException;
	
}
