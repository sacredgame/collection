package com.cg.bpw.test;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.cg.bpw.exception.PaymentWalletException;
import com.cg.bpw.service.IBankService;
import com.cg.bpw.service.BankServiceImpl;

public class TestClass {

	@Test(expected=PaymentWalletException.class)
    public void validateName_null() throws PaymentWalletException{
        IBankService service=new BankServiceImpl();
        service.validateName(null);
    }
    
    @Test
    public void validateName1() throws PaymentWalletException{
    
        String name="Dinesh96";
        IBankService service=new BankServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test
    public void validateName2() throws PaymentWalletException{
    
        String name="Dinu";
        IBankService service=new BankServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(true,result);
    }
    @Test
    public void validateName3() throws PaymentWalletException{
    
        String name="dinesh";
        IBankService service=new BankServiceImpl();
        boolean result= service.validateName(name);
        Assert.assertEquals(false,result);
    }
    @Test(expected=PaymentWalletException.class)
    public void validateMobNum_null() throws PaymentWalletException{
        IBankService service=new BankServiceImpl();
        service.validateMoileNo(null);
    }
    
    @Test
    public void validateMobNum1() throws PaymentWalletException{
    
        String mobNo="KBCM756487";
        IBankService service=new BankServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
    @Test
    public void validateMobNum2() throws PaymentWalletException{
    
        String mobNo="9867988985";
        IBankService service=new BankServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(true,result);
    }
    @Test
    public void validateMobNum3() throws PaymentWalletException{
    
        String mobNo="88053";
        IBankService service=new BankServiceImpl();
        boolean result= service.validateMoileNo(mobNo);
        Assert.assertEquals(false,result);
    }
	
}
