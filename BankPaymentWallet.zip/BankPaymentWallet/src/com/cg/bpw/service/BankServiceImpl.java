package com.cg.bpw.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bpw.dao.IBankDAO;
import com.cg.bpw.dao.BankDAOImpl;
import com.cg.bpw.dto.User;
import com.cg.bpw.exception.PaymentWalletException;


public class BankServiceImpl implements IBankService{

	IBankDAO dao  = new BankDAOImpl();
	
	
	@Override
	public void createAccount(User customer) {
		dao.createAccount(customer);		
	}

	@Override
	public void addMoney(String mobileNo, double amount) {
		dao.addMoney(mobileNo, amount);
		
	}

	@Override
	public void withdraw(String mobileNo, double amount) {
		dao.withdraw(mobileNo, amount);
		
	}

	@Override
	public double checkBalance(String mobileNo) {
		return dao.checkBalance(mobileNo);
	}

	@Override
	public void moneyTransfer(String sender, String reciever, double amount) {
		dao.moneyTransfer(sender, reciever, amount);
		
	}

	@Override
	public boolean validateName(String name) throws PaymentWalletException {
		if(name == null)
			throw new PaymentWalletException("Null value found");
		Pattern p = Pattern.compile("[A-Z]{1}[a-z]{1,10}");
		Matcher m = p.matcher(name); 
		if(!m.matches())
			System.out.println("Name invalid! Name should start with capital letter and should be of minimum 2 characters e.g Dinesh");
		return m.matches();
		
	}

	@Override
	public boolean validateAge(float age)  throws PaymentWalletException {
	
	/*		if(age == 0)
				throw new PaymentWalletException("Age cannot be  null");
			else if(age >100)
				throw new PaymentWalletException("Age cannot be  greater than 100");
			else if(age < 0)
				throw new PaymentWalletException("Age cannot be a negative number");
			else if(age >17)
				return true;
			else
				return false;
	}*/
		try{
			if(age == 0)
				System.out.println("Age cannot be  null");
			else if(age >100)
				System.out.println("Age cannot be  greater than 100");
			else if(age < 0)
				System.out.println("Age cannot be a negative number");
			else if(age <=17)
				System.out.println("Minimum age to open account is 18");
			else if(age >17)
				return true;
	} catch (Exception e) {
		e.printStackTrace();
	}
		return false;
	}
	@Override
	public boolean validateMoileNo(String mobileNo) throws PaymentWalletException{
		try{
			if(mobileNo == null)
				throw new PaymentWalletException("Null value found");
			Pattern p = Pattern.compile("[6789][0-9]{9}");
			Matcher m = p.matcher(mobileNo);
			if(!m.matches())
				System.out.println("Mobile Number Invalid! Please enter valid Indian mobile number of 10 digits e.g 9867988985");
			return m.matches();
	} catch (Exception e) {
		e.printStackTrace();
	}
		return false;
	}

	@Override
	public boolean validateAmount(double amount) throws PaymentWalletException {
		if(amount == 0)
			System.out.println("Amount cannot be zero");
		String am = String.valueOf(amount);
		if(!am.matches("\\d{3,5}\\.\\d{0,2}"))
			System.out.println("Invalid Amount! Minimum amount should be 100 and maximum limit is  Rs.99,999");
		return (am.matches("\\d{3,5}\\.\\d{0,2}"));
	}

	@Override
	public boolean validateAccount(String mobileNo) throws PaymentWalletException {
		return dao.validateAccount(mobileNo);
			
	}

}
