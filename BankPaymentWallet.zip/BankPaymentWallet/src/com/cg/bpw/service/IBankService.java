package com.cg.bpw.service;

import com.cg.bpw.dto.User;
import com.cg.bpw.exception.PaymentWalletException;

public interface IBankService {

	public void createAccount(User customer);
	
	public void addMoney(String mobileNo, double amount);
	
	public void withdraw(String mobileNo, double amount);
	
	public double checkBalance(String mobileNo);
	
	public void moneyTransfer(String sender, String reciever, double amount);
	
	
	public boolean validateAccount(String mobileNo) throws PaymentWalletException;
	
	public boolean validateName(String name) throws PaymentWalletException;
	
	public boolean validateAge(float age) throws PaymentWalletException;
	
	public boolean validateMoileNo(String mobileNo) throws PaymentWalletException;
	
	public boolean validateAmount(double amount) throws PaymentWalletException;
			
}
